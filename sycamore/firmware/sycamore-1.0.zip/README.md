# sycamore
Firmware for the Sycamore Eurorack module
