class Drummer:
    def drumList():
        pass
